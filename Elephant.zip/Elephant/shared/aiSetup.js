export const AI_SETUP_RUNTIME_BROWSER = 'browser'
export const AI_SETUP_RUNTIME_OLLAMA = 'ollama'

export const AI_SETUP_RECOMMENDED_IDS = Object.freeze({
  browser: Object.freeze({
    embedding: 'minilm-embedding-browser',
    chat: 'qwen25-05b-chat-browser'
  }),
  ollama: Object.freeze({
    embedding: 'nomic-embed-text-ollama',
    chat: 'llama32-ollama-chat'
  })
})

export const getRecommendedSetupModels = (catalog = [], runtime = AI_SETUP_RUNTIME_BROWSER) => {
  const ids = AI_SETUP_RECOMMENDED_IDS[runtime] || AI_SETUP_RECOMMENDED_IDS.browser
  const findById = (id) => catalog.find((model) => model.id === id)
  const findFallback = (purpose) => catalog.find((model) => model.purpose === purpose && isRunnableSetupModel(model))
  return {
    embedding: findById(ids.embedding) || findFallback('embedding') || null,
    chat: findById(ids.chat) || findFallback('chat') || null
  }
}

export const isRunnableSetupModel = (model = {}) => {
  if (model.provider === AI_SETUP_RUNTIME_BROWSER) {
    return ['text-generation', 'feature-extraction'].includes(model.task)
  }
  if (model.provider === AI_SETUP_RUNTIME_OLLAMA) {
    return ['chat-completion', 'embedding'].includes(model.task)
  }
  return false
}

export const getModelRuntimeName = (model = {}) => model.browserModel || model.model || model.pull || model.id || ''

export const createSelectionPatchForModel = (model = {}) => {
  if (!model.purpose || !model.id) return {}
  return { [model.purpose]: model.id }
}

export const isSetupModelInstalled = (model = {}, installedModels = []) => {
  const runtimeName = getModelRuntimeName(model)
  return installedModels.some((installed) => {
    const installedRuntimeName = installed.browserModel || installed.model || installed.name || installed.id
    return installed.id === model.id || installed.id === runtimeName || installedRuntimeName === runtimeName
  })
}
