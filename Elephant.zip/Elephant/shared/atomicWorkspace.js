export const MODEL_GROUPS = Object.freeze([
  {
    id: 'embedding',
    label: 'Embedding / Search',
    description: 'Vector search, semantic search and Note Graph retrieval.',
    purposes: ['embedding']
  },
  {
    id: 'tagging',
    label: 'Tagging / Naming',
    description: 'Very small models are enough for auto-tagging, auto-naming and quick metadata extraction.',
    purposes: ['tagging', 'naming']
  },
  {
    id: 'wiki',
    label: 'Wiki / Summary',
    description: 'Stronger instruction models for cited synthesis, summaries and restructuring.',
    purposes: ['wiki', 'summary']
  },
  {
    id: 'chat',
    label: 'Chat / Agent',
    description: 'Assistant, RAG chat, tool use and external agent bridges.',
    purposes: ['chat', 'agent']
  },
  {
    id: 'audio',
    label: 'Audio',
    description: 'Speech-to-text and text-to-speech engines.',
    purposes: ['speech-to-text', 'text-to-speech']
  }
])

export const MODEL_PURPOSES = Object.freeze([
  'embedding',
  'tagging',
  'naming',
  'wiki',
  'summary',
  'chat',
  'agent',
  'speech-to-text',
  'text-to-speech'
])

export { ATOMIC_AI_FEATURES } from './atomicAiEngine'

export const ATOMIC_MODEL_CATALOG = Object.freeze([
  {
    id: 'minilm-embedding-browser',
    name: 'MiniLM Embeddings Browser',
    purpose: 'embedding',
    category: 'embedding',
    provider: 'browser',
    engine: 'transformersjs',
    task: 'feature-extraction',
    browserModel: 'Xenova/all-MiniLM-L6-v2',
    backend: 'auto',
    dtype: 'q8',
    local: true,
    pull: '',
    size: '~90 MB',
    quality: 'fast',
    notes: 'Browser-cached embedding model. WebGPU when available, WebCPU/WASM fallback otherwise.'
  },
  {
    id: 'qwen25-05b-tagging-browser',
    name: 'Qwen2.5 0.5B Browser',
    purpose: 'tagging',
    category: 'tagging',
    provider: 'browser',
    engine: 'transformersjs',
    task: 'text-generation',
    browserModel: 'onnx-community/Qwen2.5-0.5B-Instruct',
    backend: 'auto',
    dtype: 'q4',
    local: true,
    pull: '',
    size: '~750 MB',
    quality: 'tiny',
    notes: 'Default browser model for tags, titles and short structured outputs.'
  },
  {
    id: 'qwen25-05b-naming-browser',
    name: 'Qwen2.5 0.5B Browser',
    purpose: 'naming',
    category: 'tagging',
    provider: 'browser',
    engine: 'transformersjs',
    task: 'text-generation',
    browserModel: 'onnx-community/Qwen2.5-0.5B-Instruct',
    backend: 'auto',
    dtype: 'q4',
    local: true,
    pull: '',
    size: '~750 MB',
    quality: 'tiny',
    notes: 'Same cached model reused for automatic note naming.'
  },
  {
    id: 'qwen25-05b-summary-browser',
    name: 'Qwen2.5 0.5B Browser',
    purpose: 'summary',
    category: 'wiki',
    provider: 'browser',
    engine: 'transformersjs',
    task: 'text-generation',
    browserModel: 'onnx-community/Qwen2.5-0.5B-Instruct',
    backend: 'auto',
    dtype: 'q4',
    local: true,
    pull: '',
    size: '~750 MB',
    quality: 'small',
    notes: 'MVP summary model. Not perfect, but it runs inside Electron without Ollama.'
  },
  {
    id: 'qwen25-05b-wiki-browser',
    name: 'Qwen2.5 0.5B Browser',
    purpose: 'wiki',
    category: 'wiki',
    provider: 'browser',
    engine: 'transformersjs',
    task: 'text-generation',
    browserModel: 'onnx-community/Qwen2.5-0.5B-Instruct',
    backend: 'auto',
    dtype: 'q4',
    local: true,
    pull: '',
    size: '~750 MB',
    quality: 'small',
    notes: 'Small cited synthesis model for the first working browser AI path.'
  },
  {
    id: 'qwen25-05b-chat-browser',
    name: 'Qwen2.5 0.5B Browser Chat',
    purpose: 'chat',
    category: 'chat',
    provider: 'browser',
    engine: 'transformersjs',
    task: 'text-generation',
    browserModel: 'onnx-community/Qwen2.5-0.5B-Instruct',
    backend: 'auto',
    dtype: 'q4',
    local: true,
    pull: '',
    size: '~750 MB',
    quality: 'small',
    notes: 'Recommended MVP chat model. Downloads through the browser cache with progress.'
  },
  {
    id: 'qwen25-coder-05b-agent-browser',
    name: 'Qwen2.5 Coder 0.5B Browser',
    purpose: 'agent',
    category: 'chat',
    provider: 'browser',
    engine: 'transformersjs',
    task: 'text-generation',
    browserModel: 'onnx-community/Qwen2.5-Coder-0.5B-Instruct',
    backend: 'auto',
    dtype: 'q4',
    local: true,
    pull: '',
    size: '~750 MB',
    quality: 'code-small',
    notes: 'Small browser-side code/agent model. Useful for testing workflows before larger models.'
  },
  {
    id: 'nomic-embed-text-ollama',
    name: 'Nomic Embed Text Ollama',
    purpose: 'embedding',
    category: 'embedding',
    provider: 'ollama',
    engine: 'ollama',
    task: 'embedding',
    model: 'nomic-embed-text',
    pull: 'nomic-embed-text',
    endpoint: 'http://127.0.0.1:11434',
    local: true,
    size: '~274 MB',
    quality: 'local',
    notes: 'Recommended Ollama embedding model for semantic search and automatic note links.'
  },
  {
    id: 'llama32-ollama-chat',
    name: 'Llama 3.2 Ollama Chat',
    purpose: 'chat',
    category: 'chat',
    provider: 'ollama',
    engine: 'ollama',
    task: 'chat-completion',
    model: 'llama3.2',
    pull: 'llama3.2',
    endpoint: 'http://127.0.0.1:11434',
    local: true,
    size: 'Ollama',
    quality: 'local',
    notes: 'Recommended Ollama chat model when you prefer a system runtime instead of Browser WebGPU/WebCPU.'
  },
  {
    id: 'codex-compatible',
    name: 'Codex-compatible Agent',
    purpose: 'agent',
    category: 'chat',
    provider: 'openai-compatible',
    local: false,
    pull: '',
    size: 'remote',
    quality: 'agent',
    notes: 'External agent bridge configured in AI > Providers.'
  },
  {
    id: 'llama32-1b-webllm-reference',
    name: 'Llama 3.2 1B WebLLM Reference',
    purpose: 'chat',
    category: 'chat',
    provider: 'browser-webllm',
    engine: 'webllm',
    task: 'chat-completion',
    browserModel: 'Llama-3.2-1B-Instruct-q4f16_1-MLC',
    backend: 'webgpu',
    dtype: 'q4f16_1',
    local: true,
    pull: '',
    size: '~879 MB VRAM',
    quality: 'webgpu',
    notes: 'Kept as a future WebLLM target. Current MVP uses Transformers.js first for WebGPU/WebCPU fallback.'
  },
  {
    id: 'whisper-tiny-browser',
    name: 'Whisper Tiny Browser',
    purpose: 'speech-to-text',
    category: 'audio',
    provider: 'browser',
    engine: 'transformersjs',
    task: 'automatic-speech-recognition',
    browserModel: 'Xenova/whisper-tiny',
    backend: 'auto',
    dtype: 'q8',
    local: true,
    pull: '',
    size: '~150 MB',
    quality: 'tiny',
    notes: 'Speech-to-text browser target for the next audio iteration.'
  },
  {
    id: 'kokoro-82m-browser',
    name: 'Kokoro 82M Browser',
    purpose: 'text-to-speech',
    category: 'audio',
    provider: 'browser',
    engine: 'transformersjs',
    task: 'text-to-speech',
    browserModel: 'onnx-community/Kokoro-82M-v1.0-ONNX',
    backend: 'auto',
    dtype: 'q8',
    local: true,
    pull: '',
    size: '~326 MB',
    quality: 'small',
    notes: 'Text-to-speech browser target for the next audio iteration.'
  }
])

export {
  ATOMIC_PLUGIN_MANIFESTS,
  EXTENSION_ACTION_STATUS,
  EXTENSION_PLUGIN_IDS,
  EXTENSION_PLUGIN_RUNTIMES,
  EXTENSION_TASK_ACTIONS,
  PROGRAMMATIC_TASK_TEMPLATES,
  createDefaultPluginState,
  createDefaultTaskState,
  createTaskRunResult,
  createTaskStepResult,
  isExecutableTaskAction,
  mergePluginState,
  mergeTaskState,
  normalizePluginManifest,
  normalizeProgrammaticTask,
  resolvePluginRuntime,
  updatePluginState,
  updateTaskState
} from './extensions'

export const getModelGroups = () => MODEL_GROUPS

export const getModelsByPurpose = (purpose, catalog = ATOMIC_MODEL_CATALOG) => {
  if (!MODEL_PURPOSES.includes(purpose)) return []
  return catalog.filter((model) => model.purpose === purpose)
}

export const getModelsByCategory = (category, catalog = ATOMIC_MODEL_CATALOG) => {
  return catalog.filter((model) => model.category === category || model.purpose === category)
}

export const createDefaultModelSelection = () => MODEL_PURPOSES.reduce((selection, purpose) => {
  selection[purpose] = ''
  return selection
}, {})
