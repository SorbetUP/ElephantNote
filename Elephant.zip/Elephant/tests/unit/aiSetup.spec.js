import { describe, expect, it } from 'vitest'
import { ATOMIC_MODEL_CATALOG } from 'common/elephantnote/atomicWorkspace'
import {
  createSelectionPatchForModel,
  getModelRuntimeName,
  getRecommendedSetupModels,
  isRunnableSetupModel,
  isSetupModelInstalled
} from 'common/elephantnote/aiSetup'

describe('AI setup workflow helpers', () => {
  it('chooses runnable Browser defaults for embeddings and chat', () => {
    const recommended = getRecommendedSetupModels(ATOMIC_MODEL_CATALOG, 'browser')

    expect(recommended.embedding).toMatchObject({
      id: 'minilm-embedding-browser',
      provider: 'browser',
      task: 'feature-extraction'
    })
    expect(recommended.chat).toMatchObject({
      id: 'qwen25-05b-chat-browser',
      provider: 'browser',
      task: 'text-generation'
    })
    expect(isRunnableSetupModel(recommended.embedding)).toBe(true)
    expect(isRunnableSetupModel(recommended.chat)).toBe(true)
  })

  it('chooses runnable Ollama defaults for embeddings and chat', () => {
    const recommended = getRecommendedSetupModels(ATOMIC_MODEL_CATALOG, 'ollama')

    expect(recommended.embedding).toMatchObject({
      id: 'nomic-embed-text-ollama',
      provider: 'ollama',
      task: 'embedding',
      model: 'nomic-embed-text'
    })
    expect(recommended.chat).toMatchObject({
      id: 'llama32-ollama-chat',
      provider: 'ollama',
      task: 'chat-completion',
      model: 'llama3.2'
    })
    expect(isRunnableSetupModel(recommended.embedding)).toBe(true)
    expect(isRunnableSetupModel(recommended.chat)).toBe(true)
  })

  it('stores model slots with stable catalog ids, not runtime ids', () => {
    const model = ATOMIC_MODEL_CATALOG.find((item) => item.id === 'minilm-embedding-browser')

    expect(getModelRuntimeName(model)).toBe('Xenova/all-MiniLM-L6-v2')
    expect(createSelectionPatchForModel(model)).toEqual({
      embedding: 'minilm-embedding-browser'
    })
  })

  it('recognizes installed Browser and Ollama models by runtime name', () => {
    const browserEmbedding = ATOMIC_MODEL_CATALOG.find((item) => item.id === 'minilm-embedding-browser')
    const ollamaChat = ATOMIC_MODEL_CATALOG.find((item) => item.id === 'llama32-ollama-chat')

    expect(isSetupModelInstalled(browserEmbedding, [
      { id: 'minilm-embedding-browser', browserModel: 'Xenova/all-MiniLM-L6-v2' }
    ])).toBe(true)
    expect(isSetupModelInstalled(ollamaChat, [
      { id: 'llama3.2', name: 'llama3.2', provider: 'ollama' }
    ])).toBe(true)
  })
})
